public class FloydHeapify {

    static void floydHeapSort(int arr[], int len){
        int j =(len-1)/2;
        for(int i=j;i>=0; i--){
            heapify(arr,len,i);
        }
    }

        static void heapify(int arr[], int len, int i)
        {
            int least = i; //assigning the least value to the root.
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < len && arr[left] < arr[least]) //comparing the root with the left child
                least = left;

            if (right < len && arr[right] < arr[least]) //comparing the root with the right child
                least = right;

            if (least != i) {
                int temp = arr[i];
                arr[i] = arr[least];
                arr[least] = temp;

                heapify(arr, len, least);
            }
        }


        static void heapSort(int arr[], int len)
        {

            for (int i = len / 2 - 1; i >= 0; i--)
                heapify(arr, len, i);


            for (int i = len - 1; i >= 0; i--) {


                int temp = arr[0];
                arr[0] = arr[i];
                arr[i] = temp;

                heapify(arr, i, 0);
            }
        }

        static void printArray(int arr[], int len)
        {
            for (int i = 0; i < len; i++)
                System.out.print(arr[i] + " ");
            System.out.println();
        }

        public static void main(String[] args)
        {
            int arr[] = { 1,4,5,3,7,9,11,13,10,12,15,14,18,20,25};
            int len = arr.length;

            System.out.println("The array before any heap is implemented: ");
            printArray(arr,len);

            floydHeapSort(arr,len);
            System.out.println("The min-heap(Floyd's) array is: ");
            printArray(arr,len);

            heapSort(arr, len);
            System.out.println("The sorted min-heap array is ");
            printArray(arr, len);
        }
    }


